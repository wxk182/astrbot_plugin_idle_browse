#!/usr/bin/env python3
"""批量打开多个 URL，输出 {url: {text, image}} 的 JSON。用法: read_pages.py <url1> [url2 ...]"""
import sys, json, asyncio
from playwright.async_api import async_playwright

import glob, os, shutil

def _find_chrome():
    env = os.environ.get("PW_CHROME_PATH", "").strip()
    if env and os.path.exists(env):
        return env
    for pat in (
        os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome"),
        os.path.expanduser("~/.cache/ms-playwright/chromium_headless_shell-*/chrome-linux*/headless_shell"),
    ):
        found = sorted(glob.glob(pat))
        if found:
            return found[-1]
    for name in ("chromium", "chromium-browser", "google-chrome", "chrome"):
        p = shutil.which(name)
        if p:
            return p
    return None

EXE = _find_chrome()
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
MAX_CHARS = 2500


async def main(urls):
    out = {}
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=EXE, headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--hide-scrollbars"],
        )
        ctx = await browser.new_context(user_agent=UA, locale="zh-CN", timezone_id="Asia/Shanghai")
        for url in urls:
            text, image = "", ""
            try:
                page = await ctx.new_page()
                await page.goto(url, wait_until="load", timeout=45000)
                await page.wait_for_timeout(2200)
                text = await page.evaluate(
                    """() => {
                        const pick = document.querySelector('article') || document.body;
                        return (pick.innerText || '').replace(/\\n{2,}/g, '\\n').trim();
                    }"""
                )
                image = await page.evaluate(
                    """() => {
                        const m = document.querySelector('meta[property="og:image"]');
                        if (m && m.content && m.content.startsWith('http')) return m.content;
                        const i = document.querySelector('article img, .content img, main img, img');
                        return i && i.src ? i.src : '';
                    }"""
                )
                await page.close()
            except Exception as e:
                print(f"[warn] {url}: {e}", file=sys.stderr)
            out[url] = {"text": (text or "")[:MAX_CHARS], "image": image or ""}
        await browser.close()
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1:]))
