#!/usr/bin/env python3
"""B站数据：bili_fetch.py list <数量>  或  bili_fetch.py detail <bvid> [SESSDATA]"""
import sys, json, urllib.request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Referer": "https://www.bilibili.com/"}


def get_json(url, headers=None):
    req = urllib.request.Request(url, headers=headers or H)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def fetch_list(count=10):
    data = get_json(f"https://api.bilibili.com/x/web-interface/popular?ps={count}&pn=1").get("data", {}).get("list", [])
    out = []
    for v in data:
        out.append({
            "title": v.get("title", ""),
            "bvid": v.get("bvid", ""),
            "href": f"https://www.bilibili.com/video/{v.get('bvid','')}",
            "owner": v.get("owner", {}).get("name", ""),
            "pic": v.get("pic", ""),
        })
    return out


def fetch_detail(bvid, sessdata=""):
    headers = dict(H)
    if sessdata:
        headers["Cookie"] = f"SESSDATA={sessdata}"
    view = get_json(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}", headers)
    if view.get("code") != 0:
        return ""
    d = view["data"]
    aid, cid = d.get("aid"), d.get("cid")
    parts = [f"标题：{d.get('title','')}", f"UP主：{d.get('owner',{}).get('name','')}", f"简介：{d.get('desc','')}"]
    try:
        c = get_json(f"https://api.bilibili.com/x/v2/reply?type=1&oid={aid}&ps=8&sort=2", headers)
        if c.get("code") == 0:
            reps = c.get("data", {}).get("replies") or []
            msgs = [str(r.get("content", {}).get("message", "")).replace("\n", " ")[:80] for r in reps[:8]]
            if msgs:
                parts.append("热门评论：" + " / ".join(msgs))
    except Exception:
        pass
    try:
        p = get_json(f"https://api.bilibili.com/x/player/v2?aid={aid}&cid={cid}", headers)
        subs = p.get("data", {}).get("subtitle", {}).get("subtitles", []) or []
        if subs:
            url = subs[0].get("subtitle_url", "")
            if url.startswith("//"):
                url = "https:" + url
            if url:
                sj = get_json(url, headers)
                text = " ".join(x.get("content", "") for x in sj.get("body", [])).strip()
                if text:
                    parts.append("字幕：" + text[:2500])
    except Exception:
        pass
    return "\n".join(parts)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("{}")
        sys.exit(0)
    if sys.argv[1] == "list":
        print(json.dumps(fetch_list(int(sys.argv[2]) if len(sys.argv) > 2 else 10), ensure_ascii=False))
    elif sys.argv[1] == "detail":
        print(fetch_detail(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else ""))
