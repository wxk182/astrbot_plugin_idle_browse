#!/usr/bin/env python3
"""打开多个页面，输出每页的 [{title, href}] JSON。用法: fetch_links.py <url1> [url2 ...]"""
import sys, json, asyncio
from playwright.async_api import async_playwright

import glob, os, shutil

def _find_chrome():
    env = os.environ.get("PW_CHROME_PATH", "").strip()
    if env and os.path.exists(env):
        return env
    for pat in (
        os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome"),
        os.path.expanduser("~/.cache/ms-playwright/chromium_headless_shell-*/chrome-linux*/headless_shell"),
    ):
        found = sorted(glob.glob(pat))
        if found:
            return found[-1]
    for name in ("chromium", "chromium-browser", "google-chrome", "chrome"):
        p = shutil.which(name)
        if p:
            return p
    return None

EXE = _find_chrome()
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")


async def main(urls):
    result = {}
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=EXE, headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--hide-scrollbars"],
        )
        ctx = await browser.new_context(user_agent=UA, locale="zh-CN", timezone_id="Asia/Shanghai")
        for url in urls:
            items = []
            try:
                page = await ctx.new_page()
                await page.goto(url, wait_until="load", timeout=45000)
                await page.wait_for_timeout(2500)
                raw = await page.eval_on_selector_all(
                    "a",
                    "els => els.map(e => ({t:(e.innerText||'').trim(), h:e.href||''}))"
                    ".filter(x => x.t.length>=8 && x.t.length<=60 && x.h.startsWith('http'))",
                )
                seen = set()
                for x in raw:
                    key = x["t"]
                    if key in seen:
                        continue
                    seen.add(key)
                    items.append({"title": key.replace("\n", " "), "href": x["h"]})
                    if len(items) >= 20:
                        break
            except Exception as e:
                print(f"[warn] {url}: {e}", file=sys.stderr)
            finally:
                try:
                    await page.close()
                except Exception:
                    pass
            result[url] = items
        await browser.close()
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1:]))
