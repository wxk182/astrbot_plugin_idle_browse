#!/usr/bin/env python3
"""打开一个 URL，输出 {"text": 正文, "image": 首图} 的 JSON。用法: read_page.py <url> [max_chars]"""
import sys, json, asyncio
from playwright.async_api import async_playwright

import glob, os, shutil

def _find_chrome():
    env = os.environ.get("PW_CHROME_PATH", "").strip()
    if env and os.path.exists(env):
        return env
    for pat in (
        os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome"),
        os.path.expanduser("~/.cache/ms-playwright/chromium_headless_shell-*/chrome-linux*/headless_shell"),
    ):
        found = sorted(glob.glob(pat))
        if found:
            return found[-1]
    for name in ("chromium", "chromium-browser", "google-chrome", "chrome"):
        p = shutil.which(name)
        if p:
            return p
    return None

EXE = _find_chrome()
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")


async def main(url, max_chars=3000):
    text, image = "", ""
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=EXE, headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--hide-scrollbars"],
        )
        ctx = await browser.new_context(user_agent=UA, locale="zh-CN", timezone_id="Asia/Shanghai")
        page = await ctx.new_page()
        try:
            await page.goto(url, wait_until="load", timeout=45000)
            await page.wait_for_timeout(2500)
            text = await page.evaluate(
                """() => {
                    const pick = document.querySelector('article') || document.body;
                    return (pick.innerText || '').replace(/\\n{2,}/g, '\\n').trim();
                }"""
            )
            image = await page.evaluate(
                """() => {
                    const m = document.querySelector('meta[property="og:image"]');
                    if (m && m.content && m.content.startsWith('http')) return m.content;
                    const i = document.querySelector('article img, .content img, main img, img');
                    return i && i.src ? i.src : '';
                }"""
            )
        except Exception as e:
            print(f"[warn] {e}", file=sys.stderr)
        finally:
            await browser.close()
    print(json.dumps({"text": text[:int(max_chars)], "image": image}, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else 3000))
