import asyncio
import json
import math
import sys
from pathlib import Path
import random
import re
import time
from datetime import datetime
from urllib.parse import urlparse

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import Image, Plain
from astrbot.api.star import Context, Star, register
from astrbot.core.message.message_event_result import MessageChain
from astrbot.core.platform.message_type import MessageType
from astrbot.core.star.star_tools import StarTools



@register("astrbot_plugin_idle_browse", "dsh", "空闲冲浪并分享", "1.0.0")
class IdleBrowse(Star):
    def __init__(self, context: Context, config: dict | None = None):
        super().__init__(context, config)
        self.config = config or {}
        self.data_dir = StarTools.get_data_dir("astrbot_plugin_idle_browse")
        self.seen_file = self.data_dir / "seen.json"
        self.local_memory_file = self.data_dir / "reading_memory.json"
        self.daily_file = self.data_dir / "daily.json"
        self.topics_file = self.data_dir / "topics.json"
        self.pool_file = self.data_dir / "pool.json"
        self.feedback_file = self.data_dir / "feedback.json"
        self.last_share_file = self.data_dir / "last_share.json"
        self.pending_file = self.data_dir / "pending_send.json"
        self.status_file = self.data_dir / "status.json"
        self.script_dir = Path(__file__).resolve().parent / "scripts"
        self._retry_at = 0.0
        self._owner_last = time.time()
        self._last_active = time.time()
        self._last_browse = 0.0
        self._task = None

    def _cfg(self, key, default=None):
        try:
            v = self.config.get(key, default)
        except Exception:
            v = default
        return v if v is not None and v != "" else default

    def _script(self, key, name):
        p = str(self._cfg(key, "") or "").strip()
        if p and Path(p).exists():
            return p
        return str(self.script_dir / name)

    def _set_status(self, state, detail=""):
        try:
            self.status_file.write_text(
                json.dumps({"state": state, "detail": detail, "ts": time.time()}, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    async def _api_status(self):
        logger.info("[idle-browse] status api called")
        try:
            st = json.loads(self.status_file.read_text(encoding="utf-8"))
        except Exception:
            st = {"state": "idle", "detail": "", "ts": 0}
        daily = self._load_daily()
        return {"status": "ok", "data": {
            "state": st.get("state", "idle"),
            "detail": st.get("detail", ""),
            "since": st.get("ts", 0),
            "today": daily.get("count", 0),
            "daily_limit": int(self._cfg("max_browse_per_day", 6)),
            "pending": bool(self._load_pending()),
            "quiet": self._in_quiet(),
        }}

    async def _api_records(self):
        from astrbot.api.web import request
        q = str(request.query.get("q", "") or "").lower()
        src = str(request.query.get("source", "") or "").lower()
        items = self._load_local_memory()
        out = []
        for x in reversed(items):
            blob = (str(x.get("title", "")) + " " + str(x.get("thought", ""))).lower()
            if q and q not in blob:
                continue
            if src:
                hay = (str(x.get("source", "")) + " " + str(x.get("href", ""))).lower()
                if src not in hay:
                    continue
            out.append(x)
        return {"status": "ok", "data": {"items": out[:100]}}

    async def _api_feedback(self):
        fb = self._load_feedback()
        rows = sorted(fb.items(), key=lambda kv: kv[1], reverse=True)[:20]
        items = [{"topic": k.split("|")[0], "score": v} for k, v in rows if v > 0]
        return {"status": "ok", "data": {"items": items}}

    async def _api_stats(self):
        from collections import Counter
        items = self._load_local_memory()
        counter = Counter()
        for x in items:
            day = str(x.get("ts", ""))[:10]
            if day:
                counter[day] += 1
        days = sorted(counter.keys())[-7:]
        return {"status": "ok", "data": {"days": days, "counts": [counter[d] for d in days]}}

    async def _api_action(self):
        from astrbot.api.web import request
        try:
            data = await request.json(default={}) or {}
        except Exception:
            data = {}
        action = str(data.get("action", ""))

        if action == "reset_daily":
            self._save_daily({"date": self._today(), "count": 0})
            return {"status": "ok", "data": {"msg": "今日计数已重置"}}

        return {"status": "error", "message": "未知操作"}

    def _load_seen(self):
        try:
            return json.loads(self.seen_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _save_seen(self, seen):
        try:
            self.seen_file.write_text(json.dumps(seen[-300:], ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _load_local_memory(self):
        try:
            return json.loads(self.local_memory_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _save_local_memory(self, items):
        try:
            cap = int(self._cfg("local_memory_max", 100))
            self.local_memory_file.write_text(
                json.dumps(items[-cap:], ensure_ascii=False, indent=1), encoding="utf-8"
            )
        except Exception:
            pass

    def _today(self):
        return datetime.now().strftime("%Y-%m-%d")

    def _save_pending(self, entry, thought):
        try:
            self.pending_file.write_text(
                json.dumps({"entry": entry, "thought": thought, "ts": time.time()}, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _load_pending(self):
        try:
            d = json.loads(self.pending_file.read_text(encoding="utf-8"))
            return d if d and d.get("entry") else None
        except Exception:
            return None

    def _clear_pending(self):
        try:
            self.pending_file.unlink(missing_ok=True)
        except Exception:
            pass

    def _persona(self):
        name = str(self._cfg("persona_name", "")).strip()
        return f"你是{name}。" if name else ""

    def _time_hint(self):
        h = datetime.now().hour
        if 6 <= h < 10:
            return "现在是早上，偏资讯和新闻"
        if 10 <= h < 18:
            return "现在是白天，资讯和轻松内容都行"
        if 18 <= h < 24:
            return "现在是晚上，挑轻松一点的"
        return "现在是深夜，挑安静、不吵的内容"

    def _load_feedback(self):
        try:
            return json.loads(self.feedback_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_feedback(self, fb):
        try:
            self.feedback_file.write_text(json.dumps(fb, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _like_text(self):
        fb = self._load_feedback()
        if not fb:
            return ""
        top = sorted(fb.items(), key=lambda kv: kv[1], reverse=True)[:3]
        words = [k.split("|")[0] for k, v in top if v > 0]
        return "主人最近爱看：" + "、".join(words) if words else ""

    def _record_like(self, title):
        sig = self._topic_sig(title)
        if not sig:
            return
        key = "|".join(sorted(sig))[:120]
        fb = self._load_feedback()
        fb[key] = int(fb.get(key, 0)) + 1
        # 只保留分数最高的 100 个
        if len(fb) > 100:
            fb = dict(sorted(fb.items(), key=lambda kv: kv[1], reverse=True)[:100])
        self._save_feedback(fb)

    def _mark_share(self, entry, thought=""):
        try:
            self.last_share_file.write_text(
                json.dumps({"ts": time.time(), "title": entry["title"], "thought": thought, "done": False}, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _consume_feedback(self):
        """主人最近两小时内回复过，就算喜欢上一条分享。"""
        try:
            d = json.loads(self.last_share_file.read_text(encoding="utf-8"))
        except Exception:
            return
        if d.get("done"):
            return
        if time.time() - float(d.get("ts", 0)) <= 7200:
            d["done"] = True
            self.last_share_file.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
            self._record_like(d.get("title", ""))
            logger.info("[idle-browse] 主人回复了，记一次喜欢")

    def _blocked(self):
        raw = str(self._cfg("blocked_words", "") or "")
        return [w.strip() for w in raw.replace("，", "\n").splitlines() if w.strip()]

    def _is_blocked(self, *texts):
        words = self._blocked()
        if not words:
            return False
        blob = " ".join(str(t) for t in texts if t)
        return any(w in blob for w in words)

    def _custom_sites(self):
        raw = str(self._cfg("custom_sites", "") or "")
        out = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "|" in line:
                name, url = line.split("|", 1)
            else:
                name, url = "", line
            name = name.strip()
            url = url.strip()
            if url.startswith("http"):
                out.append((name or url, url))
        return out

    @staticmethod
    @staticmethod
    def _norm_url(url):
        return str(url).split("?")[0].split("#")[0].rstrip("/")

    @staticmethod
    def _same_site(base, href):
        try:
            b = urlparse(base).netloc.lower()
            h = urlparse(href).netloc.lower()
            if not b or not h:
                return False
            return b == h or h.endswith("." + b) or b.endswith("." + h)
        except Exception:
            return False

    def _topic_sig(self, title):
        t = re.sub(r"[^\w\u4e00-\u9fa5]", "", title or "")
        if len(t) < 2:
            return {t} if t else set()
        return {t[i:i + 2] for i in range(len(t) - 1)}

    def _load_topics(self):
        try:
            return json.loads(self.topics_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _save_topics(self, topics):
        try:
            self.topics_file.write_text(json.dumps(topics[-200:], ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _topic_dup(self, title):
        sig = self._topic_sig(title)
        if not sig:
            return False
        try:
            threshold = float(self._cfg("topic_similarity", 0.62))
        except Exception:
            threshold = 0.62
        for h in self._load_topics():
            hs = set(str(h).split("|"))
            if not hs:
                continue
            union = len(sig | hs)
            if union and len(sig & hs) / union >= threshold:
                return True
        return False

    def _remember_topic(self, title):
        topics = self._load_topics()
        topics.append("|".join(sorted(self._topic_sig(title))))
        self._save_topics(topics)

    def _load_daily(self):
        try:
            d = json.loads(self.daily_file.read_text(encoding="utf-8"))
        except Exception:
            d = {}
        if d.get("date") != self._today():
            return {"date": self._today(), "count": 0}
        return d

    def _save_daily(self, d):
        try:
            self.daily_file.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _in_quiet(self):
        try:
            h = datetime.now().hour
            start = int(self._cfg("quiet_start_hour", 1))
            end = int(self._cfg("quiet_end_hour", 7))
            if start == end:
                return False
            if start < end:
                return start <= h < end
            return h >= start or h < end
        except Exception:
            return False

    async def initialize(self):
        self._task = asyncio.create_task(self._loop())
        self._set_status("idle", "等待触发")
        try:
            self.context.register_web_api("/astrbot_plugin_idle_browse/page/status", self._api_status, ["GET"], "冲浪状态")
            self.context.register_web_api("/astrbot_plugin_idle_browse/page/records", self._api_records, ["GET"], "阅读记录")
            self.context.register_web_api("/astrbot_plugin_idle_browse/page/feedback", self._api_feedback, ["GET"], "兴趣排行")
            self.context.register_web_api("/astrbot_plugin_idle_browse/page/stats", self._api_stats, ["GET"], "统计")
            self.context.register_web_api("/astrbot_plugin_idle_browse/page/action", self._api_action, ["POST"], "面板操作")
        except Exception as e:
            logger.warning(f"[idle-browse] 注册面板 API 失败: {e}")
        logger.info(
            "[idle-browse] 启动：空闲 %s 分钟，每日上限 %s 轮，分享给 %s",
            self._cfg("idle_minutes", 60),
            self._cfg("max_browse_per_day", 6),
            self._cfg("target_qq", ""),
        )

    async def terminate(self):
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    @filter.on_llm_request()
    async def _mark_working(self, event, req):
        self._set_status("working", "AI 正在处理")
        try:
            d = json.loads(self.last_share_file.read_text(encoding="utf-8"))
            if d and not d.get("done") and time.time() - float(d.get("ts", 0)) < 7200:
                note = (
                    f"\n\n（你刚才主动私聊分享过一条内容：《{d.get('title','')}》。"
                    f"你当时的想法：{str(d.get('thought',''))[:200]}。如果主人提起，你知道自己说过什么。）"
                )
                req.system_prompt = (req.system_prompt or "") + note
        except Exception:
            pass

    @filter.on_llm_response()
    async def _mark_work_done(self, event, resp):
        self._set_status("idle", "")

    @filter.event_message_type(filter.EventMessageType.ALL)
    async def track(self, event: AstrMessageEvent):
        now = time.time()
        self._last_active = now
        try:
            if event.get_message_type() == MessageType.FRIEND_MESSAGE:
                sender = str(event.get_sender_id())
                if sender == str(self._cfg("target_qq", "")).strip():
                    self._owner_last = now
                    self._consume_feedback()
        except Exception:
            pass

    async def _loop(self):
        while True:
            try:
                await asyncio.sleep(max(30, int(self._cfg("scan_interval_sec", 60))))
                if not self._cfg("enabled", True):
                    self._set_status("idle", "已关闭")
                    continue
                if self._in_quiet():
                    self._set_status("quiet", "静默时段")
                    continue
                idle = int(self._cfg("idle_minutes", 60)) * 60
                now = time.time()
                source = str(self._cfg("idle_source", "owner_private"))
                base = self._owner_last if source == "owner_private" else self._last_active
                if now - base < idle:
                    self._set_status("idle", "")
                    continue
                if now - self._last_browse < idle:
                    continue
                if now < self._retry_at:
                    continue
                daily = self._load_daily()
                if daily["count"] >= int(self._cfg("max_browse_per_day", 6)):
                    self._set_status("idle", "")
                    continue
                if await self._retry_pending():
                    continue
                self._last_browse = now
                sent = await self._browse_and_share(now)
                self._set_status("idle", "等待触发")
                if sent:
                    daily = self._load_daily()
                    daily["count"] += 1
                    self._save_daily(daily)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error(f"[idle-browse] 循环出错: {e}")

    async def _run_script(self, script, *args, timeout=150):
        py = str(self._cfg("browser_python", "") or "").strip()
        if not py or not Path(py).exists():
            py = sys.executable
        try:
            proc = await asyncio.create_subprocess_exec(
                py, script, *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            if proc.returncode != 0:
                logger.warning(f"[idle-browse] 脚本失败: {err.decode('utf-8','ignore')[-300:]}")
            return out.decode("utf-8", "ignore")
        except Exception as e:
            logger.warning(f"[idle-browse] 脚本异常: {e}")
            return ""

    async def _collect_links(self):
        cap = max(1, int(self._cfg("max_candidates", 20)))
        sources, labels = [], {}
        for name, url in self._custom_sites():
            if url not in sources:
                sources.append(url); labels[url] = name

        random.shuffle(sources)
        take = max(1, int(self._cfg("source_per_round", 3)))
        chosen = sources[:take] if sources else []
        per_source = max(1, math.ceil(cap / max(1, len(chosen) + (1 if self._cfg("enable_bilibili", False) else 0))))

        seen = {self._norm_url(x) for x in self._load_seen()}
        items = []
        if chosen:
            raw = await self._run_script(
                self._script("links_script", "fetch_links.py"), *chosen
            )
            try:
                data = json.loads(raw or "{}")
            except Exception:
                data = {}
            for url in chosen:
                added = 0
                for it in data.get(url, []):
                    href = it.get("href", "")
                    title = it.get("title", "")
                    if not href or self._norm_url(href) in seen:
                        continue
                    if self._is_blocked(title):
                        continue
                    if not self._same_site(url, href):
                        continue
                    items.append({"title": title, "href": href, "source": labels.get(url, url)})
                    added += 1
                    if added >= per_source or len(items) >= cap:
                        break
                if len(items) >= cap:
                    break

        if self._cfg("enable_bilibili", False) and len(items) < cap:
            raw_b = await self._run_script(
                self._script("bili_script", "bili_fetch.py"),
                "list", str(int(self._cfg("bili_count", 10))),
            )
            try:
                vids = json.loads(raw_b or "[]")
            except Exception:
                vids = []
            random.shuffle(vids)
            for v in vids:
                href = v.get("href", "")
                if not href or self._norm_url(href) in seen:
                    continue
                items.append({"title": v.get("title", ""), "href": href, "source": "B站", "pic": v.get("pic", "")})
                if len(items) >= cap:
                    break
        return items

    async def _provider(self):
        pid = str(self._cfg("provider_id", "")).strip()
        provider = None
        if pid:
            try:
                provider = self.context.get_provider_by_id(pid)
            except Exception:
                provider = None
        return provider or self.context.get_using_provider()

    def _interrupted(self, start_ts):
        return self._owner_last > start_ts

    async def _pick_many(self, items, count):
        provider = await self._provider()
        if provider is None:
            return []
        listing = "\n".join(f"{i+1}. {it['title']}" for i, it in enumerate(items))
        like = self._like_text()
        prompt = (
            f"{self._persona()}你在刷新闻。{self._time_hint()}。\n"
            + (f"{like}\n" if like else "")
            + f"从下面挑 {count} 条你最想点进去看的，按兴趣排序。\n"
            "只回复序号，用逗号隔开，例如 3,7,1。\n\n" + listing
        )
        try:
            resp = await provider.text_chat(prompt=prompt, system_prompt="你只输出序号。")
            text = (resp.completion_text or "").strip()
            nums = [int(x) for x in re.findall(r"\d+", text)]
            picked = []
            for n in nums:
                if 1 <= n <= len(items) and items[n - 1] not in picked:
                    picked.append(items[n - 1])
                if len(picked) >= count:
                    break
            return picked
        except Exception as e:
            logger.error(f"[idle-browse] 挑选失败: {e}")
        return []

    async def _read(self, entry):
        url = entry["href"]
        if "bilibili.com/video/" in url:
            bvid = url.rstrip("/").split("/")[-1]
            raw = await self._run_script(
                self._script("bili_script", "bili_fetch.py"),
                "detail", bvid, str(self._cfg("bili_cookie", "")),
            )
            return raw.strip(), str(entry.get("pic", "")).strip()
        raw = await self._run_script(
            self._script("read_script", "read_page.py"),
            url, str(int(self._cfg("read_chars", 2500))),
        )
        try:
            d = json.loads(raw)
            return str(d.get("text", "")).strip(), str(d.get("image", "")).strip()
        except Exception:
            return raw.strip(), ""

    async def _compose(self, item, body):
        provider = await self._provider()
        if provider is None:
            return ""
        recent = self._load_local_memory()[-5:]
        history = "\n".join(f"- 看过《{r['title']}》，想法：{r['thought']}" for r in recent)
        tone = str(self._cfg(
            "share_tone",
            "像朋友随手分享。可以带点情绪，但不要每条都用同一个开头，也不要每句都带感叹。一两句，像随手发的那种。",
        ))
        prompt = (
            (f"你最近看过：\n{history}\n\n" if history else "")
            + f"你刚点开看了一条新闻。\n标题：{item['title']}\n链接：{item['href']}\n"
            f"正文开头：\n{body[:2000]}\n\n"
            f"给主人发一句私信。要求：{tone} 只输出要发的那句话，不要标题，不要列表。"
        )
        try:
            resp = await provider.text_chat(
                prompt=prompt,
                system_prompt=(f"{self._persona()}只输出要发给主人的那一段话。").strip(),
            )
            return (resp.completion_text or "").strip()
        except Exception as e:
            logger.error(f"[idle-browse] 写想法失败: {e}")
        return ""

    async def _remember_local(self, item, thought):
        if not self._cfg("remember_local", True):
            return
        items = self._load_local_memory()
        items.append({
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "title": item["title"],
            "href": item["href"],
            "source": item.get("source", ""),
            "thought": thought,
        })
        self._save_local_memory(items)

    async def _remember_livingmemory(self, item, thought):
        if not self._cfg("remember_to_livingmemory", True):
            return
        try:
            meta = self.context.get_registered_star("astrbot_plugin_livingmemory")
            inst = getattr(meta, "star_cls", None) if meta else None
            initializer = getattr(inst, "initializer", None) if inst else None
            engine = getattr(initializer, "memory_engine", None) if initializer else None
            if engine is None:
                return
            session = f"{self._cfg('platform_id','')}:FriendMessage:{self._cfg('target_qq','')}"
            await engine.add_memory(
                content=f"我在网上看到《{item['title']}》，链接 {item['href']}。我的想法：{thought}",
                session_id=session,
                importance=0.6,
                metadata={"type": "reading", "url": item["href"], "title": item["title"]},
            )
        except Exception as e:
            logger.warning(f"[idle-browse] 同步 livingmemory 失败: {e}")

    async def _send_raw(self, entry, thought):
        self._set_status("browsing", "发送中")
        target = str(self._cfg("target_qq", "")).strip()
        platform_id = str(self._cfg("platform_id", "")).strip()
        if not (target and platform_id):
            return False
        session = f"{platform_id}:FriendMessage:{target}"
        first = [Plain(f"{entry['title']}\n{entry['href']}")]
        pic = str(entry.get("pic", "")).strip()
        if pic.startswith("http://"):
            pic = "https://" + pic[7:]
        logger.info(f"[idle-browse] 发送带图={bool(pic)} url={pic[:80]}")
        if pic:
            try:
                first.append(Image.fromURL(pic))
            except Exception:
                pass
        try:
            await self.context.send_message(session, MessageChain(first))
            await asyncio.sleep(2)
            await self.context.send_message(session, MessageChain([Plain(thought)]))
            return True
        except Exception as e:
            logger.error(f"[idle-browse] 发送失败: {e}")
            return False

    async def _retry_pending(self):
        d = self._load_pending()
        if not d:
            return False
        if time.time() - float(d.get("ts", 0)) < 300:
            return False
        ok = await self._send_raw(d["entry"], d["thought"])
        if ok:
            self._clear_pending()
            logger.info("[idle-browse] 补发成功")
        return ok

    async def _browse_and_share(self, start_ts):
        self._set_status("browsing", "浏览中")
        items = await self._collect_links()
        if not items:
            self._retry_at = time.time() + 1800
            self._set_status("idle", "")
            logger.info("[idle-browse] 没抓到内容，30 分钟后重试")
            return False
        if self._interrupted(start_ts):
            return False

        n = max(1, int(self._cfg("read_count", 3)))
        picked = await self._pick_many(items, n)
        picked = [x for x in picked if not self._topic_dup(x["title"])]
        if not picked or self._interrupted(start_ts):
            logger.info("[idle-browse] 挑到的都是重复话题，跳过")
            return False

        # 网页一次浏览器批量读
        web_urls = [x["href"] for x in picked if "bilibili.com/video/" not in x["href"]]
        batch = {}
        if web_urls:
            raw = await self._run_script(
                self._script("read_pages_script", "read_pages.py"),
                *web_urls,
            )
            try:
                batch = json.loads(raw or "{}")
            except Exception:
                batch = {}

        entries = []
        for x in picked:
            href = x["href"]
            if "bilibili.com/video/" in href:
                body, pic = await self._read(x)
            else:
                d = batch.get(href, {}) or {}
                body, pic = str(d.get("text", "")).strip(), str(d.get("image", "")).strip()
            if len(body) < 80:
                continue
            if self._is_blocked(x["title"], body[:1500]):
                logger.info("[idle-browse] 命中屏蔽词，跳过")
                continue
            entry = dict(x)
            if pic and not entry.get("pic"):
                entry["pic"] = pic
            entry["_body"] = body
            entries.append(entry)
            self._remember_topic(entry["title"])
            seen = self._load_seen()
            if self._norm_url(href) not in {self._norm_url(x) for x in seen}:
                seen.append(self._norm_url(href))
                self._save_seen(seen)

        if not entries:
            logger.info("[idle-browse] 读到的正文都太短")
            return False
        if self._interrupted(start_ts):
            return False

        # 按概率决定分不分享
        try:
            prob = float(self._cfg("share_probability", 0.3))
        except Exception:
            prob = 0.3
        share = random.random() < prob

        chosen = None
        thought = ""
        if share:
            chosen = random.choice(entries)
            thought = await self._compose(chosen, chosen["_body"]) or ""

        # 全部记住（分享的那条带上想法）
        for e in entries:
            await self._remember_local(
                e, thought if (chosen is not None and e["href"] == chosen["href"]) else ""
            )
            await self._remember_livingmemory(
                e, thought if (chosen is not None and e["href"] == chosen["href"]) else ""
            )

        if not (share and chosen and thought):
            logger.info(f"[idle-browse] 读了 {len(entries)} 条，这次不分享")
            return False

        ok = await self._send_raw(chosen, thought)
        if not ok:
            self._save_pending(chosen, thought)
            logger.info("[idle-browse] 发送失败，已存待补发")
            return False
        self._mark_share(chosen, thought)
        logger.info(f"[idle-browse] 读了 {len(entries)} 条，分享 1 条")
        return True

    @filter.command("冲浪")
    async def manual_browse(self, event: AstrMessageEvent):
        yield event.plain_result("冲浪中，稍等…")
        self._set_status("browsing", "手动冲浪")
        try:
            items = await self._collect_links()
            if not items:
                yield event.plain_result("没抓到链接，看看日志")
                return
            picked = await self._pick_many(items, 1)
            if not picked:
                yield event.plain_result("没挑出来")
                return
            entry = picked[0]
            body, pic = await self._read(entry)
            if len(body) < 80:
                yield event.plain_result("正文太短，换一条再试")
                return
            if self._is_blocked(entry["title"], body[:1500]):
                yield event.plain_result("这条命中屏蔽词，跳过了")
                return
            if pic and not entry.get("pic"):
                entry["pic"] = pic
            thought = await self._compose(entry, body)
            if not thought:
                yield event.plain_result("写不出想法")
                return
            first = [Plain(f"{entry['title']}\n{entry['href']}")]
            p2 = str(entry.get("pic", "")).strip()
            if p2.startswith("http://"):
                p2 = "https://" + p2[7:]
            if p2:
                try:
                    first.append(Image.fromURL(p2))
                except Exception:
                    pass
            yield event.chain_result(first)
            await asyncio.sleep(2)
            yield event.plain_result(thought)
            # 手动冲浪也记进阅读记忆
            self._remember_topic(entry["title"])
            seen = self._load_seen()
            if self._norm_url(entry["href"]) not in {self._norm_url(x) for x in seen}:
                seen.append(self._norm_url(entry["href"]))
                self._save_seen(seen)
            await self._remember_local(entry, thought)
            await self._remember_livingmemory(entry, thought)
        except Exception as e:
            yield event.plain_result(f"出错了：{e}")
        finally:
            self._set_status("idle", "")
