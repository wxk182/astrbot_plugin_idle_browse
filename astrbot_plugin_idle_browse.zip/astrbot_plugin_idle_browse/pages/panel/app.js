const $ = (id) => document.getElementById(id);

const STATE_MAP = {
  idle: { text: "空闲", color: "var(--muted)" },
  browsing: { text: "上网", color: "var(--info)" },
  quiet: { text: "静默", color: "#af52de" },
  working: { text: "工作", color: "var(--good)" },
};

let bridge = null;

function getBridge() { return window.AstrBotPluginView || window.AstrBotPluginPage; }
async function waitBridge(timeout = 6000) {
  const t0 = Date.now();
  while (!getBridge() && Date.now() - t0 < timeout) await new Promise((r) => setTimeout(r, 100));
  return getBridge();
}
function unwrap(r) {
  if (r && r.status === "ok" && Object.prototype.hasOwnProperty.call(r, "data")) return r.data;
  if (r && r.status === "error") throw new Error(r.message || "请求失败");
  return r || {};
}
async function apiGet(path, params) { return unwrap(await bridge.apiGet(path, params || {})); }
async function apiPost(path, body) { return unwrap(await bridge.apiPost(path, body || {})); }

let noteUntil = 0;
function note(msg) {
  noteUntil = Date.now() + 5000;
  const t = $("toast");
  if (t) {
    t.textContent = msg;
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 5000);
  }
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function loadStatus() {
  try {
    const s = await apiGet("page/status");
    const m = STATE_MAP[s.state] || STATE_MAP.idle;
    $("stateName").textContent = m.text;
    $("dot").style.background = m.color;
    if (Date.now() > noteUntil) $("stateDetail").textContent = s.detail || "";
    $("today").textContent = `${s.today}/${s.daily_limit}`;
    $("pending").textContent = s.pending ? "有" : "无";
  } catch (e) {
    $("stateName").textContent = "读取失败";
    $("stateDetail").textContent = String(e.message || e);
  }
}

async function loadChart() {
  try {
    const d = await apiGet("page/stats");
    const box = $("chart");
    const map = {};
    (d.days || []).forEach((day, i) => { map[day] = d.counts[i]; });
    const out = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const dt = new Date(today.getTime() - i * 86400000);
      const key = dt.toISOString().slice(0, 10);
      out.push([key.slice(5), map[key] || 0]);
    }
    const max = Math.max(...out.map((x) => x[1]), 1);
    box.innerHTML = out.map(([label, n]) => {
      const h = Math.round((n / max) * 80) + 4;
      return `<div class="bar"><b>${n || ""}</b><i style="height:${h}px"></i><span>${label}</span></div>`;
    }).join("");
  } catch (e) {}
}

async function loadFeedback() {
  try {
    const d = await apiGet("page/feedback");
    const box = $("feedback");
    const items = d.items || [];
    if (!items.length) { box.innerHTML = '<div class="empty">还没积累</div>'; return; }
    const max = Math.max(...items.map((x) => x.score), 1);
    box.innerHTML = items.map((x) => `
      <div class="row">
        <span class="name">${esc(x.topic)}</span>
        <span class="bar"><i style="width:${Math.round((x.score / max) * 100)}%"></i></span>
        <span class="score">${x.score}</span>
      </div>`).join("");
  } catch (e) {}
}

async function loadRecords() {
  try {
    const d = await apiGet("page/records", {});
    const box = $("records");
    if (!d.items || !d.items.length) { box.innerHTML = '<div class="empty">还没有记录</div>'; return; }
    box.innerHTML = d.items.map((x) => `
      <div class="item">
        <div class="meta"><span>${esc(x.ts || "")}</span><span>${esc(x.source || "")}</span></div>
        <div class="title"><a href="${esc(x.href)}" target="_blank" rel="noopener">${esc(x.title || "")}</a></div>
        <div class="thought">${esc(x.thought || "")}</div>
      </div>`).join("");
  } catch (e) {}
}

$("refresh").onclick = () => { loadStatus(); loadChart(); loadFeedback(); loadRecords(); };
$("resetDaily").onclick = async () => {
  try { await apiPost("page/action", { action: "reset_daily" }); note("今日计数已重置"); loadStatus(); }
  catch (e) { note("失败：" + (e.message || e)); }
};

async function boot() {
  bridge = await waitBridge();
  if (!bridge) {
    $("stateName").textContent = "bridge 未注入";
    $("stateDetail").textContent = "请从插件视图打开";
    return;
  }
  try { if (bridge.ready) await bridge.ready(); } catch (e) {}
  loadStatus(); loadChart(); loadFeedback(); loadRecords();
  setInterval(loadStatus, 15000);
}
boot();
